//
//  BidMachine.h
//  BidMachine
//
//  Created by Ilia Lozhkin on 20.06.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for BidMachine.
FOUNDATION_EXPORT double BidMachineVersionNumber;

//! Project version string for BidMachine.
FOUNDATION_EXPORT const unsigned char BidMachineVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BidMachine/PublicHeader.h>


