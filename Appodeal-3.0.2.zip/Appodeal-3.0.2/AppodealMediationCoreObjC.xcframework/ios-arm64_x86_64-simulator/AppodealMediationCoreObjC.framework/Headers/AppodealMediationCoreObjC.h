//
//  AppodealMediationCore_ObjC.h
//  AppodealMediationCore-ObjC
//
//  Created by Stas Kochkin on 10/09/2018.
//  Copyright © 2018 Stas Kochkin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AppodealMediationCoreObjC/AMCMediationController.h>
#import <AppodealMediationCoreObjC/AMCAdUnitProtocol.h>

//! Project version number for AppodealMediationCore_ObjC.
FOUNDATION_EXPORT double AppodealMediationCore_ObjCVersionNumber;

//! Project version string for AppodealMediationCore_ObjC.
FOUNDATION_EXPORT const unsigned char AppodealMediationCore_ObjCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppodealMediationCore_ObjC/PublicHeader.h>


