//
//  BidMachineAdapterCore.h
//  BidMachineAdapterCore
//
//  Created by Ilia Lozhkin on 18.07.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for BidMachineAdapterCore.
FOUNDATION_EXPORT double BidMachineAdapterCoreVersionNumber;

//! Project version string for BidMachineAdapterCore.
FOUNDATION_EXPORT const unsigned char BidMachineAdapterCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BidMachineAdapterCore/PublicHeader.h>
